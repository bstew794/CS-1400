print("My name is Braeden Stewart.")
print('My computer is ready to go!')
print ("wake me up before you go go...")